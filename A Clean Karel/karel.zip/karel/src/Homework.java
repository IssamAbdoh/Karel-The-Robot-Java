import stanford.karel.SuperKarel;


public class Homework extends SuperKarel {

    /* You fill the code here */

}
